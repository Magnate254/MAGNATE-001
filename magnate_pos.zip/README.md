# MAGNATE POS (Streamlit) - SQLite + PDF Receipts

This project is a Point-of-Sale system built with Streamlit, with:
- Inventory management (Category, Supplier, Cost price, Selling price, Wholesale price, Stock, Reorder level, Expiry, Barcode, UOM, Notes)
- Cart & Checkout with VAT and Discount applied at checkout
- Receipt preview and PDF generation (compact receipt size)
- SQLite persistence for products and sales (pos.db)
- CSV export for sales reports

## Files
- `app.py` - main Streamlit app
- `requirements.txt` - Python dependencies
- `magnate_logo.png` - the logo used in header and receipts
- `pos.db` - created automatically on first run (contains products and sales)

## Setup
1. Create virtual environment (recommended)
```bash
python -m venv .venv
source .venv/bin/activate   # macOS/Linux
.venv\Scripts\activate    # Windows (PowerShell)
```

2. Install packages
```bash
pip install -r requirements.txt
```

3. Run the app
```bash
streamlit run app.py
```

4. The app will create `pos.db` in the same folder (if not present) and seed sample data.

## Notes
- The app persists products and sales in `pos.db`. Back up this file for long-term storage.
- PDF receipts are generated using `reportlab`; ensure `magnate_logo.png` is present for logo on receipts.
- For deployment, push this folder to GitHub and connect to Streamlit Cloud or deploy on a server supporting Streamlit.
