import streamlit as st
import pandas as pd
from datetime import datetime, date
import io, os, sqlite3, json
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import landscape
from reportlab.lib.units import mm
from reportlab.lib.utils import ImageReader

# Config
DB_FILE = "pos.db"
LOGO_FILENAME = "magnate_logo.png"
VAT_DEFAULT = 16.0  # percent default VAT
RECEIPT_WIDTH_MM = 80  # typical receipt width
RECEIPT_HEIGHT_MM = 200  # flexible height

st.set_page_config(page_title="MAGNATE POS", layout="wide")

# --- Database helpers ---
def get_db_conn():
    conn = sqlite3.connect(DB_FILE, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db_conn()
    cur = conn.cursor()
    # products table stores product metadata and stock
    cur.execute("""
    CREATE TABLE IF NOT EXISTS products (
        id TEXT PRIMARY KEY,
        sku TEXT,
        name TEXT,
        category TEXT,
        supplier TEXT,
        cost_price REAL,
        price REAL,
        wholesale_price REAL,
        stock INTEGER,
        reorder_level INTEGER,
        expiry TEXT,
        barcode TEXT,
        uom TEXT,
        notes TEXT
    )
    """)
    # sales table stores sale header
    cur.execute("""
    CREATE TABLE IF NOT EXISTS sales (
        id TEXT PRIMARY KEY,
        date TEXT,
        customer TEXT,
        payment TEXT,
        items TEXT, -- JSON list of items
        total REAL,
        vat REAL,
        discount REAL
    )
    """)
    conn.commit()
    return conn

# Seed sample products if table empty
def seed_products(conn):
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) FROM products")
    if cur.fetchone()[0] == 0:
        sample = [
            ("p1","1001","Orthopedic Knee Brace","Braces","MedSupplies Ltd",1500,2500,2200,10,5,NULL,"111111","Piece","Adjustable size"),
            ("p2","1002","Spine Support Belt","Supports","OrthoImports",1200,1800,1500,8,3,NULL,"222222","Piece","")
        ]
        cur.executemany("""INSERT OR REPLACE INTO products VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""", sample)
        conn.commit()

def load_products_df(conn):
    df = pd.read_sql_query("SELECT * FROM products ORDER BY name", conn, parse_dates=["expiry"])
    # ensure correct dtypes
    if "expiry" in df.columns:
        df["expiry"] = pd.to_datetime(df["expiry"], errors="coerce").dt.date
    return df

def save_product_row(conn, row):
    cur = conn.cursor()
    cur.execute("""INSERT OR REPLACE INTO products VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""", (
        row["id"], row["sku"], row["name"], row["category"], row["supplier"],
        row["cost_price"], row["price"], row["wholesale_price"], int(row["stock"]),
        int(row.get("reorder_level",0)),
        row["expiry"].isoformat() if (row.get("expiry") and isinstance(row.get("expiry"), date)) else row.get("expiry"),
        row.get("barcode"), row.get("uom"), row.get("notes")
    ))
    conn.commit()

def delete_product(conn, pid):
    cur = conn.cursor()
    cur.execute("DELETE FROM products WHERE id = ?", (pid,))
    conn.commit()

def save_sale(conn, sale):
    cur = conn.cursor()
    cur.execute("""INSERT OR REPLACE INTO sales VALUES (?,?,?,?,?,?,?)""", (
        sale["id"], sale["date"], sale["customer"], sale["payment"],
        json.dumps(sale["items"]), sale["total"], sale.get("vat",0.0), sale.get("discount",0.0)
    ))
    conn.commit()

def load_sales_df(conn):
    df = pd.read_sql_query("SELECT id, date, customer, payment, total, vat, discount FROM sales ORDER BY date DESC", conn)
    return df

# Initialize DB
conn = init_db()
seed_products(conn)

# --- Streamlit session state setup ---
if "db_conn" not in st.session_state:
    st.session_state.db_conn = conn

if "cart" not in st.session_state:
    st.session_state.cart = []

# Utility functions for cart/products
def add_to_cart(product, qty=1):
    for item in st.session_state.cart:
        if item["id"] == product["id"]:
            item["qty"] += qty
            return
    st.session_state.cart.append({**product, "qty": qty})

def remove_from_cart(pid):
    st.session_state.cart = [i for i in st.session_state.cart if i["id"] != pid]

def update_qty(pid, qty):
    for i in st.session_state.cart:
        if i["id"] == pid:
            i["qty"] = max(1, qty)

def subtotal():
    return sum(i["price"] * i["qty"] for i in st.session_state.cart)

def apply_vat_and_discount(subtotal_val, vat_pct, discount_pct):
    discount_amount = subtotal_val * (discount_pct/100.0)
    subtotal_after_discount = subtotal_val - discount_amount
    vat_amount = subtotal_after_discount * (vat_pct/100.0)
    total = subtotal_after_discount + vat_amount
    return {"discount_amount": discount_amount, "vat_amount": vat_amount, "total": total}

# PDF generation: smaller receipt width and compact layout
def generate_pdf_receipt(sale):
    buffer = io.BytesIO()
    PAGE_WIDTH = RECEIPT_WIDTH_MM * mm
    PAGE_HEIGHT = RECEIPT_HEIGHT_MM * mm
    c = canvas.Canvas(buffer, pagesize=(PAGE_WIDTH, PAGE_HEIGHT))
    x_margin = 6 * mm
    y = PAGE_HEIGHT - 8 * mm

    logo_path = LOGO_FILENAME if os.path.exists(LOGO_FILENAME) else None
    if logo_path:
        try:
            img = ImageReader(logo_path)
            img_w, img_h = img.getSize()
            draw_w = 30 * mm
            draw_h = draw_w * (img_h / img_w)
            c.drawImage(img, x_margin, y - draw_h, width=draw_w, height=draw_h, preserveAspectRatio=True, mask='auto')
            logo_x_end = x_margin + draw_w + 4 * mm
        except Exception:
            logo_x_end = x_margin
    else:
        logo_x_end = x_margin

    c.setFont("Helvetica-Bold", 12)
    c.drawString(logo_x_end, y - 4 * mm, "MAGNATE 001")
    c.setFont("Helvetica", 7)
    c.drawString(logo_x_end, y - 9 * mm, "Official Point of Sale")
    y -= 18 * mm

    # Sale meta
    c.setFont("Helvetica", 7)
    c.drawString(x_margin, y, f"Receipt: {sale['id']}")
    c.drawRightString(PAGE_WIDTH - x_margin, y, f"Date: {sale['date']}")
    y -= 6 * mm
    c.drawString(x_margin, y, f"Customer: {sale['customer']}")
    c.drawRightString(PAGE_WIDTH - x_margin, y, f"Pay: {sale['payment']}")
    y -= 6 * mm

    c.line(x_margin, y, PAGE_WIDTH - x_margin, y)
    y -= 6 * mm

    # Items header
    c.setFont("Helvetica-Bold", 8)
    c.drawString(x_margin, y, "Item")
    c.drawRightString(PAGE_WIDTH - x_margin - 30*mm, y, "Qty")
    c.drawRightString(PAGE_WIDTH - x_margin - 18*mm, y, "Price")
    c.drawRightString(PAGE_WIDTH - x_margin, y, "Total")
    y -= 6 * mm
    c.setFont("Helvetica", 7)

    for it in sale["items"]:
        name = it["name"]
        qty = it["qty"]
        price = it["price"]
        total = qty * price
        # draw item name (wrap simple)
        max_chars = 30
        lines = [name[i:i+max_chars] for i in range(0, len(name), max_chars)]
        for li in lines:
            c.drawString(x_margin, y, li)
            y -= 5 * mm
        # draw qty/price/total on last line for that item
        c.drawRightString(PAGE_WIDTH - x_margin - 30*mm, y + (5*mm*len(lines)), str(qty))
        c.drawRightString(PAGE_WIDTH - x_margin - 18*mm, y + (5*mm*len(lines)), f"{price:,}")
        c.drawRightString(PAGE_WIDTH - x_margin, y + (5*mm*len(lines)), f"{total:,}")
        y -= 2 * mm
        if y < 20*mm:
            c.showPage()
            y = PAGE_HEIGHT - 8*mm

    y -= 6 * mm
    c.line(x_margin, y, PAGE_WIDTH - x_margin, y)
    y -= 6 * mm

    # Totals (discount, vat, total)
    c.setFont("Helvetica", 8)
    c.drawString(x_margin, y, f"Subtotal: KES {sale['subtotal']:,}")
    y -= 5 * mm
    c.drawString(x_margin, y, f"Discount ({sale.get('discount_pct',0)}%): -KES {sale.get('discount_amount',0):,}")
    y -= 5 * mm
    c.drawString(x_margin, y, f"VAT ({sale.get('vat_pct',0)}%): KES {sale.get('vat_amount',0):,}")
    y -= 6 * mm
    c.setFont("Helvetica-Bold", 10)
    c.drawRightString(PAGE_WIDTH - x_margin, y, f"TOTAL KES {sale['total']:,}")
    y -= 8 * mm

    c.setFont("Helvetica", 7)
    c.drawString(x_margin, y, "Thank you for your purchase!")
    y -= 5 * mm
    c.drawString(x_margin, y, "MAGNATE — Quality orthopedic supplies")

    c.showPage()
    c.save()
    buffer.seek(0)
    return buffer.read()

# --- UI and app logic ---
st.title("💳 MAGNATE POS SYSTEM")
if os.path.exists(LOGO_FILENAME):
    st.image(LOGO_FILENAME, width=140)

conn = st.session_state.db_conn
products_df = load_products_df(conn)
sales_df = load_sales_df(conn)

tabs = st.tabs(["🛍️ Products", "🛒 Cart", "📦 Inventory", "📊 Reports"])

# PRODUCTS TAB
with tabs[0]:
    st.subheader("Products")
    colA, colB = st.columns([3,1])
    with colA:
        q = st.text_input("Search by name or SKU")
    with colB:
        st.write("Quick actions")
        sku_quick = st.text_input("Enter SKU to add quickly")
        if st.button("Add SKU to Cart"):
            if sku_quick:
                row = conn.execute("SELECT * FROM products WHERE sku = ?", (sku_quick,)).fetchone()
                if row:
                    add_to_cart(dict(row), 1)
                else:
                    st.warning("SKU not found")
    df = products_df
    if q:
        df = df[df["name"].str.contains(q, case=False) | df["sku"].str.contains(q, case=False)]
    st.dataframe(df[["sku","name","category","price","stock"]], use_container_width=True)

    cols = st.columns([2,1])
    with cols[0]:
        sel = st.selectbox("Select product (by id)", df["id"])
        qty = st.number_input("Quantity", 1, 100, 1)
    with cols[1]:
        if st.button("Add to cart"):
            prod_row = conn.execute("SELECT * FROM products WHERE id = ?", (sel,)).fetchone()
            if prod_row:
                add_to_cart(dict(prod_row), qty)
                st.success("Added to cart")

# CART TAB
with tabs[1]:
    st.subheader("Cart")
    if not st.session_state.cart:
        st.info("Cart is empty")
    else:
        for it in st.session_state.cart:
            c1,c2,c3,c4 = st.columns([3,1,1,1])
            c1.write(it["name"])
            c2.write(f"KES {it['price']:,}")
            new_qty = c3.number_input("Qty", 1, it["stock"], it["qty"], key="cart_"+it["id"])
            if new_qty != it["qty"]:
                update_qty(it["id"], new_qty)
            if c4.button("Remove", key="rm_"+it["id"]):
                remove_from_cart(it["id"])
                st.experimental_rerun()
        st.markdown("---")
        st.write(f"**Subtotal:** KES {subtotal():,}")

        with st.expander("Checkout options"):
            customer = st.text_input("Customer name")
            payment = st.selectbox("Payment Method", ["Cash","Card","Mobile Money"])
            vat_pct = st.number_input("VAT %", 0.0, 100.0, VAT_DEFAULT)
            discount_pct = st.number_input("Discount %", 0.0, 100.0, 0.0)
            if st.button("Confirm & Print (PDF)"):
                sub = subtotal()
                calc = apply_vat_and_discount(sub, vat_pct, discount_pct)
                sale = {
                    "id": f"s_{int(datetime.now().timestamp())}",
                    "date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "customer": customer or "Walk-in",
                    "payment": payment,
                    "items": [{"id":i["id"], "name":i["name"], "price":i["price"], "qty":i["qty"]} for i in st.session_state.cart],
                    "subtotal": sub,
                    "discount_pct": discount_pct,
                    "discount_amount": calc["discount_amount"],
                    "vat_pct": vat_pct,
                    "vat_amount": calc["vat_amount"],
                    "total": calc["total"]
                }
                # persist sale and update stock
                save_sale(conn, sale)
                # update product stock in DB
                for it in sale["items"]:
                    conn.execute("UPDATE products SET stock = stock - ? WHERE id = ?", (it["qty"], it["id"]))
                conn.commit()
                st.session_state.cart = []
                # generate pdf and offer download
                pdf_bytes = generate_pdf_receipt(sale)
                st.success(f\"Sale complete: {sale['id']}\")
                st.download_button('⬇️ Download PDF Receipt', data=pdf_bytes, file_name=f\"receipt_{sale['id']}.pdf\", mime='application/pdf')
                st.experimental_rerun()

# INVENTORY TAB
with tabs[2]:
    st.subheader("Inventory Management")
    for idx, row in products_df.iterrows():
        st.markdown(f\"### {row['name']} (SKU: {row['sku']})\")
        c1,c2,c3,c4,c5,c6 = st.columns([1.5,1.5,1,1,1,1])
        c1.write(f\"Category: {row['category']}\")
        c2.write(f\"Supplier: {row['supplier']}\")
        c3.write(f\"Cost: KES {row['cost_price']:,}\")
        c4.write(f\"Price: KES {row['price']:,}\")
        c5.write(f\"Wholesale: KES {row['wholesale_price']:,}\")
        c6.write(f\"UOM: {row['uom']}\")

        sc, rc, ex = st.columns([1,1,1])
        new_stock = sc.number_input(\"Stock\", 0, 99999, int(row['stock']), key=f\"stock_{row['id']}\")
        new_reorder = rc.number_input(\"Reorder Level\", 0, 10000, int(row['reorder_level']), key=f\"reorder_{row['id']}\")
        expiry_default = row['expiry'] if pd.notna(row['expiry']) else date.today()
        new_expiry = ex.date_input(\"Expiry\", value=expiry_default, key=f\"exp_{row['id']}\")

        # update DB values
        if new_stock != row['stock'] or new_reorder != row['reorder_level'] or new_expiry != expiry_default:
            updated = dict(row)
            updated['stock'] = int(new_stock)
            updated['reorder_level'] = int(new_reorder)
            updated['expiry'] = new_expiry.isoformat() if isinstance(new_expiry, date) else new_expiry
            save_product_row(conn, updated)
            st.success(\"Updated product stock/details\") 
            st.experimental_rerun()

        notes = st.text_area(\"Notes\", value=row['notes'], key=f\"notes_{row['id']}\")
        if st.button(\"Delete product\", key=f\"del_{row['id']}\"):
            delete_product(conn, row['id'])
            st.experimental_rerun()
        st.markdown(\"---\")

    st.subheader(\"➕ Add new product\")
    with st.form(\"add_prod\"):
        sku = st.text_input(\"SKU\")
        name = st.text_input(\"Name\")
        category = st.selectbox(\"Category\", [\"Braces\",\"Supports\",\"Implants\",\"Consumables\",\"Other\"]) 
        supplier = st.text_input(\"Supplier\")
        cost_price = st.number_input(\"Cost price (KES)\", 0.0)
        price = st.number_input(\"Selling price (KES)\", 0.0)
        wholesale_price = st.number_input(\"Wholesale price (KES)\", 0.0)
        stock = st.number_input(\"Initial stock\", 0)
        reorder_level = st.number_input(\"Reorder level\", 0, value=5)
        expiry = st.date_input(\"Expiry date\")
        barcode = st.text_input(\"Barcode/QR\")
        uom = st.selectbox(\"UOM\", [\"Piece\",\"Box\",\"Pack\",\"Set\"])
        notes = st.text_area(\"Notes\")
        if st.form_submit_button(\"Add product\"):
            new_id = f\"p_{int(datetime.now().timestamp())}\"
            prod = {
                'id': new_id, 'sku': sku, 'name': name, 'category': category,
                'supplier': supplier, 'cost_price': cost_price, 'price': price,
                'wholesale_price': wholesale_price, 'stock': int(stock), 'reorder_level': int(reorder_level),
                'expiry': expiry.isoformat(), 'barcode': barcode, 'uom': uom, 'notes': notes
            }
            save_product_row(conn, prod)
            st.success(\"Product added\")
            st.experimental_rerun()

# REPORTS TAB
with tabs[3]:
    st.subheader(\"Sales Reports\")
    sales_df = load_sales_df(conn)
    if sales_df.empty:
        st.info(\"No sales yet\")
    else:
        st.dataframe(sales_df, use_container_width=True)
        st.write(f\"**Total sales:** KES {sales_df['total'].sum():,}\")
        csv = sales_df.to_csv(index=False).encode('utf-8')
        st.download_button(\"⬇️ Export sales CSV\", csv, \"sales.csv\", \"text/csv\")
